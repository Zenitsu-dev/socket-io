"use client";
import Image from "next/image";
import Link from "next/link";
import React from "react";
import { SignedIn, SignedOut, useClerk } from "@clerk/nextjs";
import { usePathname, useRouter } from "next/navigation";
import { Button } from "./ui/button";

const LeftSidebar = () => {
  const pathname = usePathname();
  const router = useRouter();
  const { signOut } = useClerk();

  return (
    <section
      className="left_sidebar h-[calc(100vh-5px)]"
      style={{ width: "17%" }}
    >
      <nav className="flex flex-col gap-6">
        <Link
          href="/"
          className="flex cursor-pointer items-center gap-1 pb-10 max-lg:justify-center"
        >
          <Image src="/icons/14.svg" alt="logo" width={40} height={40} />
          <h1 className="text-24 font-extrabold text-white max-lg:hidden ml-2">
            FinanceForge
          </h1>
        </Link>

        {/* Example sidebarLinks data structure for mapping */}
        {[
          { route: "/games", label: "Games", imgURL: "/icons/9.svg" },
          {
            route: "/expense-tracker",
            label: "Expense tracker",
            imgURL: "/icons/10.svg",
          },
          {
            route: "/finance-reads",
            label: "Finance reads",
            imgURL: "/icons/13.svg",
          },
          {
            route: "/recommend",
            label: "Investment recommendation",
            imgURL: "/icons/12.svg",
          },
          {
            route: "/forum",
            label: "Forum & discussions",
            imgURL: "/icons/11.svg",
          },
        ].map(({ route, label, imgURL }) => {
          const isActive =
            pathname === route || pathname.startsWith(`${route}/`);

          return (
            <Link
              href={route}
              key={label}
              className={`flex gap-3 items-center py-4 max-lg:px-4 justify-center lg:justify-start ${
                isActive ? "bg-nav-focus border-r-4 border-orange-1" : ""
              }`}
            >
              <Image src={imgURL} alt={label} width={30} height={30} />
              <p>{label}</p>
            </Link>
          );
        })}
      </nav>

      <SignedOut>
        <div className="flex-center w-full pb-14 max-lg:px-4 lg:pr-8">
          <Button asChild className="text-16 w-full bg-orange-1 font-extrabold">
            <Link href="/sign-in">Sign in</Link>
          </Button>
        </div>
      </SignedOut>

      <SignedIn>
        <div className="flex-center w-full pb-14 max-lg:px-4 lg:pr-8">
          <Button
            className="text-16 w-full bg-orange-1 font-extrabold"
            onClick={() => signOut(() => router.push("/"))}
          >
            Log Out
          </Button>
        </div>
      </SignedIn>
    </section>
  );
};

export default LeftSidebar;
