import Link from "next/link";
import React from "react";

const TransactionList = ({ data }) => {
  return (
    <div className="container w-full bg-black-1 p-6 rounded-lg text-xl">
      <div className="text-2xl flex flex-row justify-between mb-2">
        <p>Transactions </p>
        <Link
          href={"expense-tracker/transactions"}
          className=" bg-blue-700 px-2 rounded-lg"
        >
          &#8599;
        </Link>
      </div>
      {data.map((transaction) => {
        if (transaction.type == "expense") {
          return (
            <div key={transaction._id} className="flex flex-row gap-4 p-2">
              <div className="flex-grow">{transaction.title}</div>
              <div className="flex-shrink-0 text-right text-[#EB5757]">
                ${transaction.amount}
              </div>
            </div>
          );
        }
        return (
          <div key={transaction._id} className="flex flex-row gap-4 p-2">
            <div className="flex-grow">{transaction.title}</div>
            <div className="flex-shrink-0 text-right text-[#20C997]">
              ${transaction.amount}
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default TransactionList;
