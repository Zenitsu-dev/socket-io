"use client";
import { useState } from "react";

const ProductRecommendation = () => {
  const [riskTolerance, setRiskTolerance] = useState(0);
  const [investmentAmount, setInvestmentAmount] = useState(0);
  const [min_returns_1yr, setMin_returns_1yr] = useState(0);
  const [min_returns_3yr, setMin_returns_3yr] = useState(0);
  const [min_returns_5yr, setMin_returns_5yr] = useState(0);

  const [recommendedProducts, setRecommendedProducts] = useState([]);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      const response = await fetch("http://localhost:5000/recommend", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          min_lumpsum: parseFloat(investmentAmount),
          risk_level: parseFloat(riskTolerance),
          min_returns_1yr: parseFloat(min_returns_1yr),
          min_returns_3yr: parseFloat(min_returns_3yr),
          min_returns_5yr: parseFloat(min_returns_5yr),
        }),
        // mode: "no-cors", // Set mode to 'no-cors'
      });

      if (response.ok) {
        const data = await response.json();
        if (data.recommendations && data.recommendations.length > 0) {
          setRecommendedProducts(data.recommendations);
        } else {
          setError("No products found matching the criteria.");
        }
      } else {
        // Handle errors if needed (may not be possible with 'no-cors' mode)
        setError("Error connecting to the server");
      }
    } catch (err) {
      setError("Error connecting to the server");
    }
  };

  return (
    <div className="m-5">
      <h1 className="text-white-2 text-3xl">
        Investment Product Recommendation
      </h1>
      <form
        onSubmit={handleSubmit}
        className="flex flex-col gap-2 items-start my-3"
      >
        <label className="text-xl text-white-2">
          Risk Tolerance:
          <select
            value={riskTolerance}
            onChange={(e) => setRiskTolerance(e.target.value)}
            className="bg-black-1 p-2 ml-2 rounded-lg"
          >
            <option value="">Select...</option>
            <option value={1}>Low risk</option>
            <option value={2}>Low to moderate</option>
            <option value={3}>Moderate</option>
            <option value={4}>Moderately High</option>
            <option value={5}>High</option>
            <option value={6}>Very High</option>
          </select>
        </label>
        <br />
        <label className="text-xl text-white-2">Investment goal:</label>

        <div className="flex flex-row text-white-2 text-xl">
          <p>Minimum {"(%) "}returns after 1 year: </p>
          <input
            type="Number"
            name="min_returns_1yr"
            id="min_returns_1yr"
            onChange={(e) => setMin_returns_1yr(e.target.value)}
            className="bg-black-1 p-2 ml-2 rounded-lg"
          />
        </div>
        <div className="flex flex-row text-white-2 text-xl">
          <p>Minimum {"(%) "}returns after 3 year: </p>
          <input
            type="Number"
            name="min_returns_3yr"
            id="min_returns_3yr"
            onChange={(e) => setMin_returns_3yr(e.target.value)}
            className="bg-black-1 p-2 ml-2 rounded-lg"
          />
        </div>
        <div className="flex flex-row text-white-2 text-xl">
          <p>Minimum {"(%) "}returns after 5 year: </p>
          <input
            type="Number"
            name="min_returns_5yr"
            id="min_returns_5yr"
            onChange={(e) => setMin_returns_5yr(e.target.value)}
            className="bg-black-1 p-2 ml-2 rounded-lg"
          />
        </div>
        <br />
        <label className="text-xl text-white-2">
          Investment Amount:
          <input
            type="number"
            value={investmentAmount}
            onChange={(e) => setInvestmentAmount(e.target.value)}
            className="bg-black-1 p-2 ml-2 rounded-lg"
          />
        </label>
        <br />
        <button
          type="submit"
          className="bg-[#f97535] px-4 py-2 rounded-lg text-white-2"
        >
          Get Recommendation
        </button>
      </form>
      {error && <h2 style={{ color: "red" }}>{error}</h2>}
      {recommendedProducts.length > 0 && (
        <div className="text-white-2 text-lg">
          <h2>Recommended Products:</h2>
          <ul>
            {recommendedProducts.map((product, index) => (
              <li key={index}>
                <strong>{product.scheme_name}</strong>
                <br />
                <span>Category: {product.category}</span>
                <br />
                <span>Minimum Lumpsum: {product.min_lumpsum}</span>
                <br />
                <span>Risk Level: {product.risk_level}</span>
                <br />
                <span>Rating: {product.rating}</span>
                <br />
                <span>Returns (1yr): {product.returns_1yr}</span>
                <br />
                <span>Returns (3yr): {product.returns_3yr}</span>
                <br />
                <span>Returns (5yr): {product.returns_5yr}</span>
                <br />
                <span>Expense Ratio: {product.expense_ratio}</span>
                <br />
                <span>Fund Size (Cr): {product.fund_size_cr}</span>
                <br />
                <span>Fund Age (Yr): {product.fund_age_yr}</span>
                <br />
                <hr />
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default ProductRecommendation;
