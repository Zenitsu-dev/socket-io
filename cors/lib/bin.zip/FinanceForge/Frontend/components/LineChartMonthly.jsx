import React, { useEffect, useRef } from "react";
import { Chart, registerables } from "chart.js";

Chart.register(...registerables);

const LineChartMonthly = ({ data }) => {
  const chartRef = useRef(null);

  const drawChart = () => {
    const currentDate = new Date();
    const expenses = [];
    const income = [];

    for (let i = 0; i < 12; i++) {
      const month = new Date(
        currentDate.getFullYear(),
        currentDate.getMonth() - i,
        1
      );
      const monthLabel = month.toLocaleString("default", {
        month: "short",
        year: "numeric",
      });

      console.log("Checking transactions for month:", monthLabel);

      const monthExpenses = data
        .filter((t) => {
          const transactionDate = new Date(t.date);
          return (
            t.type === "expense" &&
            transactionDate.getMonth() === month.getMonth() &&
            transactionDate.getFullYear() === month.getFullYear()
          );
        })
        .reduce((sum, t) => sum + t.amount, 0);

      const monthIncome = data
        .filter((t) => {
          const transactionDate = new Date(t.date);
          return (
            t.type === "income" &&
            transactionDate.getMonth() === month.getMonth() &&
            transactionDate.getFullYear() === month.getFullYear()
          );
        })
        .reduce((sum, t) => sum + t.amount, 0);

      console.log("Month Expenses:", monthExpenses);
      console.log("Month Income:", monthIncome);

      expenses.unshift({ month: monthLabel, total: monthExpenses });
      income.unshift({ month: monthLabel, total: monthIncome });
    }

    const labels = expenses.map((e) => e.month);
    const expenseData = expenses.map((e) => e.total);
    const incomeData = income.map((i) => i.total);

    if (chartRef.current) {
      chartRef.current.destroy();
    }

    const ctx = document.getElementById("myChart").getContext("2d");
    chartRef.current = new Chart(ctx, {
      type: "line",
      data: {
        labels: labels,
        datasets: [
          {
            label: "Expenses",
            data: expenseData,
            backgroundColor: "rgba(255, 99, 132, 1)",
            borderColor: "#EB5757",
            borderWidth: 4,
            fill: false,
          },
          {
            label: "Income",
            data: incomeData,
            backgroundColor: "rgba(75, 192, 192, 1)",
            borderColor: "#20C997",
            borderWidth: 4,
            fill: false,
          },
        ],
      },
      options: {
        scales: {
          y: {
            beginAtZero: true,
          },
        },
      },
    });
  };

  useEffect(() => {
    if (Array.isArray(data)) {
      drawChart();
    } else {
      console.error("Data is not an array");
    }

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, [data]);

  return (
    <div className="bg-black-1 p-6 rounded-lg">
      <h1 className="text-2xl">Monthly income and expense </h1>
      <canvas id="myChart" width="400" height="200"></canvas>
    </div>
  );
};

export default LineChartMonthly;
