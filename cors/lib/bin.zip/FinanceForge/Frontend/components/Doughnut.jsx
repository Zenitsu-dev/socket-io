"use client";
import { Chart } from "chart.js";
import React, { useEffect, useRef } from "react";

const Doughnut = ({ data }) => {
  const chartRef = useRef(null);
  var expense = 0;
  var income = 0;

  const drawChart = () => {
    for (let index = 0; index < data.length; index++) {
      const transaction = data[index];
      if (transaction.type === "expense") {
        expense += transaction.amount;
      } else {
        income += transaction.amount;
      }
    }

    if (chartRef.current) {
      chartRef.current.destroy();
    }

    const ctx = document.getElementById("myDougnut").getContext("2d");
    chartRef.current = new Chart(ctx, {
      type: "doughnut",
      data: {
        labels: ["Expense", "Income"],
        datasets: [
          {
            label: "Income-Expense distribution",
            data: [expense, income],
            backgroundColor: ["#EB5757", "#20C997"],
            hoverOffset: 4,
          },
        ],
      },
    });
  };

  useEffect(() => {
    if (Array.isArray(data)) {
      drawChart();
    } else {
      console.error("Data is not an array");
    }

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, [data]);

  return (
    <div className="bg-black-1 p-6 rounded-lg">
      <h1 className="text-2xl mb-2">Income vs Expense</h1>
      <canvas id="myDougnut" width="400" height="200"></canvas>
    </div>
  );
};

export default Doughnut;
