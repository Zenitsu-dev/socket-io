"use client";
import { Chart } from "chart.js";
import React, { useEffect, useRef } from "react";

const CategoryDoughnut = ({ data }) => {
  const chartRef = useRef(null);
  const expenseCategories = [
    "Food & Drinks",
    "Groceries",
    "Bills",
    "Entertainment",
    "Transportation",
    "Utilities",
    "Health & Fitness",
    "Home & Personal Care",
    "Miscellaneous",
  ];

  const expense = [0, 0, 0, 0, 0, 0, 0, 0, 0];
  const drawChart = () => {
    debugger;
    for (let i = 0; i < expense.length; i++) {
      expense[i] = data
        .filter((item) => item.category === expenseCategories[i])
        .reduce((sum, item) => sum + item.amount, 0);
    }

    console.log(expense);
    if (chartRef.current) {
      chartRef.current.destroy();
    }

    const ctx = document.getElementById("categoryDougnut").getContext("2d");
    chartRef.current = new Chart(ctx, {
      type: "doughnut",
      data: {
        labels: expenseCategories,
        datasets: [
          {
            label: "Income-Expense distribution",
            data: expense,
            backgroundColor: [
              "#FF5733", // Red-Orange
              "#33FF57", // Lime Green
              "#3357FF", // Blue
              "#FF33A8", // Pink
              "#FFD133", // Yellow
              "#33FFF3", // Cyan
              "#8D33FF", // Purple
              "#FF8C33", // Orange
              "#33FF8C",
            ],
            hoverOffset: 4,
          },
        ],
      },
    });
  };

  useEffect(() => {
    if (Array.isArray(expense)) {
      drawChart();
    } else {
      console.error("Data is not an array");
    }

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, [data]);

  return (
    <div className="bg-black-1 p-6 rounded-lg">
      <h1 className="text-2xl mb-2">Category distribution</h1>
      <canvas
        id="categoryDougnut"
        width="400"
        height="200"
        className=""
      ></canvas>
    </div>
  );
};

export default CategoryDoughnut;
