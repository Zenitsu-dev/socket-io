"use client"
import Link from 'next/link'
import React from 'react'
import { useUser } from "@clerk/nextjs";

const Header = () => {
    const { isLoaded, isSignedIn, user } = useUser();
    // useEffect(() => {
    //     const fetchUser = async () => {
    //         const users = await currentUser();
    //         setUser(users);
    //         console.log(users);
    //     };
    //     fetchUser();
    // }, []);
    console.log(user);
  return (
    <div>
      {isSignedIn ? `Welcome to your account ${user?.firstName}`: <div> </div>}
      
    </div>
  )
}

export default Header