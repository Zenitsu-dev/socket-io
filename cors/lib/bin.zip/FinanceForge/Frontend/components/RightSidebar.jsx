"use client";
import { getUser } from "@/utils/actions/action";
import { useUser } from "@clerk/nextjs";
import Image from "next/image";
import React, { useEffect, useState } from "react";

const RightSidebar = () => {
  const { isLoaded, isSignedIn, user } = useUser();
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        if (isLoaded && isSignedIn) {
          const data = await getUser(user.id);
          setUserData(JSON.parse(data));
          console.log(user);
        }
      } catch (error) {
        console.error("Error creating user:", error);
      }
    };

    fetchUser();
  }, [isLoaded, isSignedIn, user]);

  const [searchQuery, setSearchQuery] = useState("");
  const [meaning, setMeaning] = useState(
    "Discover the meanings of complex financial jargon to accelerate your learning."
  );

  const fetchMeaning = async (word) => {
    try {
      const response = await fetch(
        `https://api.dictionaryapi.dev/api/v2/entries/en/${word}`
      );
      const data = await response.json();
      if (data && data.length > 0) {
        setMeaning(data[0].meanings[0].definitions[0].definition);
      } else {
        setMeaning("No definition found.");
      }
    } catch (error) {
      console.error("Error fetching the meaning:", error);
      setMeaning("Error fetching the meaning.");
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery) {
      fetchMeaning(searchQuery);
    }
  };

  return (
    <section
      style={{ width: "20%" }}
      className="right_sidebar flex flex-col gap-3 items-start text-white-2"
    >
      <div className="profile flex flex-row items-center gap-5">
        <Image
          src={user?.imageUrl}
          height={45}
          width={45}
          className="rounded-full"
        />
        <p>{user?.firstName + " " + user?.lastName}</p>
      </div>
      <p className="text-lg text-[#f97535]">
        &#9733; Exp points:{" "}
        <span className="text-lg text-white-2">{userData?.expPoints}</span>
      </p>
      <p className="text-lg text-[#f97535]">
        $ Gold: <span className="text-lg text-white-2">{userData?.gold}</span>
      </p>
      <div className="dictionary w-full">
        <form onSubmit={handleSearch} className="flex flex-row gap-2">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search for a word"
            className="search-bar p-2 rounded bg-black-3"
          />
          <button
            type="submit"
            className="search-button p-2 rounded bg-[#f97535] text-white"
          >
            Search
          </button>
        </form>
        <div className="meaning mt-3 p-2 rounded bg-gray-800 text-white">
          {meaning}
        </div>
      </div>
      <div className="globalRanking"></div>
    </section>
  );
};

export default RightSidebar;
