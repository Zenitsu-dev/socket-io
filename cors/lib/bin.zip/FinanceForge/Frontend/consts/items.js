export const items = [
    {
        type: "activity",
        name: "Gym",
        description:
            "Hit the gym for a great workout. It's a fantastic way to stay fit and healthy, though it can be tiring.",
        cost: 10,
        fun: 2,
        comfort: -2,
        health: 8,
    },
    {
        type: "activity",
        name: "Running",
        description:
            "Go for a run to clear your mind and improve your cardiovascular health. It's free and highly effective.",
        cost: 0,
        fun: 3,
        comfort: -5,
        health: 10,
    },
    {
        type: "activity",
        name: "Swimming",
        description:
            "For a small cost, you can get fit doing lengths at the local pool. It's hard work, but swimming is great exercise and you'll feel fab later!",
        cost: 5,
        fun: 0,
        comfort: -3,
        health: 7,
    },
    {
        type: "activity",
        name: "Football",
        description:
            "Join a local football game for a fun and competitive workout. Great for socializing and staying active.",
        cost: 7,
        fun: 6,
        comfort: -2,
        health: 6,
    },
    {
        type: "activity",
        name: "Golf",
        description:
            "Play a round of golf for a leisurely but engaging activity. It requires focus and provides moderate exercise.",
        cost: 20,
        fun: 4,
        comfort: 1,
        health: 4,
    },
    {
        type: "activity",
        name: "Cinema",
        description:
            "Watch the latest movies at the cinema. It's a great way to relax and enjoy some entertainment.",
        cost: 15,
        fun: 7,
        comfort: 3,
        health: 0,
    },
    {
        type: "activity",
        name: "Meet friends",
        description:
            "Spend time with friends to socialize and have fun. It's good for your mental health and wellbeing.",
        cost: 10,
        fun: 8,
        comfort: 5,
        health: 2,
    },
    {
        type: "activity",
        name: "Walking",
        description:
            "Go for a walk to enjoy some fresh air and light exercise. It's free and relaxing.",
        cost: 0,
        fun: 2,
        comfort: 0,
        health: 5,
    },
    {
        type: "activity",
        name: "Day Out",
        description:
            "Plan a day out to explore new places and have fun. It's a great way to take a break from routine.",
        cost: 30,
        fun: 9,
        comfort: 3,
        health: 1,
    },
    {
        type: "activity",
        name: "Live show",
        description:
            "Attend a live show for an exciting and entertaining experience. It's great for a night out.",
        cost: 50,
        fun: 10,
        comfort: 4,
        health: 0,
    },
    {
        type: "food",
        name: "Fine dining",
        description:
            "Enjoy a luxurious fine dining experience with gourmet meals. It's expensive but offers exceptional quality.",
        cost: 100,
        fun: 8,
        comfort: 10,
        health: 5,
    },
    {
        type: "food",
        name: "Home cooking",
        description:
            "Cook meals at home for a healthy and cost-effective option. It's rewarding and allows you to control ingredients.",
        cost: 20,
        fun: 6,
        comfort: 7,
        health: 10,
    },
    {
        type: "food",
        name: "Takeaway",
        description:
            "Order takeaway food for a convenient and tasty meal. It's quick and requires no preparation.",
        cost: 30,
        fun: 7,
        comfort: 8,
        health: 4,
    },
    {
        type: "food",
        name: "Convenience food",
        description:
            "Grab convenience food for a quick and easy option. It's not the healthiest, but it's very convenient.",
        cost: 15,
        fun: 5,
        comfort: 6,
        health: 2,
    },
    {
        type: "food",
        name: "Fast food",
        description:
            "Indulge in fast food for a tasty and quick meal. It's not the healthiest choice but offers instant satisfaction.",
        cost: 10,
        fun: 7,
        comfort: 5,
        health: 1,
    },
    {
        type: "food",
        name: "Local restaurant",
        description:
            "Dine at a local restaurant for a balance of quality and cost. It's a great way to enjoy a nice meal out.",
        cost: 40,
        fun: 8,
        comfort: 8,
        health: 6,
    },
    {
        type: "travel",
        name: "Public Transport",
        description:
            "Use public transport for an affordable and eco-friendly way to get around. It's reliable but can be crowded.",
        cost: 20,
        fun: 2,
        comfort: 3,
        health: 5,
    },
    {
        type: "travel",
        name: "Car",
        description:
            "Drive your own car for convenience and comfort. It's flexible but comes with costs for fuel and maintenance.",
        cost: 50,
        fun: 5,
        comfort: 8,
        health: 3,
    },
    {
        type: "travel",
        name: "Bicycle",
        description:
            "Ride a bicycle for a healthy and eco-friendly travel option. It's great exercise but requires effort.",
        cost: 0,
        fun: 4,
        comfort: -1,
        health: 10,
    },
    {
        type: "travel",
        name: "Taxi",
        description:
            "Take a taxi for a quick and convenient way to get around. It's more expensive but offers door-to-door service.",
        cost: 40,
        fun: 3,
        comfort: 9,
        health: 2,
    },
]