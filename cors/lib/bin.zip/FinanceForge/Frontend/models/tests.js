import { Schema, model, models } from "mongoose";

const testSchema = new Schema({
    name: {
        type: String,
        required: true,
    },
    unit: {
        type: Number,
        required: true,
    },
    questions: [
        {
            question: {
                type: String,
                required: true,
            },
            options: [
                {
                    type: String,
                    required: true,
                },
            ],
            answer: {
                type: String,
                required: true,
            }
        },// Add more questions here as needed.
    ]

});

const Test = models.Test || model("Test", testSchema);

export default Test;