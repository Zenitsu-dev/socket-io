import { Schema, model, models } from "mongoose";

const sandboxSchema = new Schema({
    name: {
        type: String,
        required: true,
    },
    problemStatement: {
        type: String,
        required: true,
    },
    initialWallet: {
        type: Number,
        required: true,
    },
    target: {
        type: Number,
        required: true,
    },
    timeLimit: {
        type: Number,
        required: true,
    },
    option1: {
        name: { type: String, required: true },
        prices: [{ type: Number, required: true }]
    },
    option2: {
        name: { type: String, required: true },
        prices: [{ type: Number, required: true }]
    },
    option3: {
        name: { type: String, required: true },
        prices: [{ type: Number, required: true }]
    },

});

const Sandbox = models.Sandbox || model("Sandbox", sandboxSchema);

export default Sandbox;