import { Schema, model, models } from "mongoose";
import User from "./users";

const transactionSchema = new Schema({
    userId: {
        type: Schema.Types.ObjectId,
        ref: User,
        required: true
    },
    transactions: [{
        title: { type: String, required: true },
        type: { type: String, enum: ['expense', 'income'], required: true }, // expense or income
        amount: { type: Number, required: true },
        category: { type: String, required: true }, // Food, Travel, Activities, etc...
        date: { type: Date, default: Date.now }, // Date of the transaction
        description: { type: String, required: true }, //
    }]

});

const Transaction = models.Transaction || model("Transaction", transactionSchema);

export default Transaction;