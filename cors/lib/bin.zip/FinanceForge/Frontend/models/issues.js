import mongoose from 'mongoose';

const commentSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true,
  },
  comment: {
    type: String,
    required: true,
  }
});

const issueSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  comments: [commentSchema]
});

const Issue = mongoose.models.Issue || mongoose.model('Issue', issueSchema);
export default Issue;
