import { Schema, model, models } from "mongoose";
import Sandbox from "./sandbox";
import Budgetgame from "./budgetgames";
import Test from "./tests";

const userSchema = new Schema({
    clerkId:{
        type: String,
        required: true,
        unique: true,
    },
    name: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        required: true,
    },
    image: {
        type: String,
    },
    expPoints: {
        type: Number,
        default: 0,
    },
    gold: {
        type: Number,
        default: 0,
    },
    sandboxSolved: [
        {
            type: Schema.Types.ObjectId,
            ref: Sandbox,
        }
    ],
    budgetgameSolved: [
        {
            type: Schema.Types.ObjectId,
            ref: Budgetgame,
        }
    ],
    testSolved: [
        {
            type: Schema.Types.ObjectId,
            ref: Test  // replace with your test model name
        }
    ]
});

const User = models.User || model("User", userSchema);

export default User;