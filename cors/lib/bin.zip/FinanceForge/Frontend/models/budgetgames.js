import { Schema, model, models } from "mongoose";

const budgetgameSchema = new Schema({
    name: {
        type: String,
        required: true,
    },
    budget: {
        type: Number,
        required: true,
    },
    time: {
        type: Number,
        required: true,
    }

});

const Budgetgame = models.Budgetgame || model("Budgetgame", budgetgameSchema);

export default Budgetgame;