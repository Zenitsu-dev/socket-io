import { connectToDb } from "@/lib/db";
import Sandbox from "@/models/sandbox";

export const POST = async (req) => {
    const { name, problemStatement, initialWallet, target, timeLimit, option1, option2, option3, option4 } = await req.json();


    try {
        await connectToDb();
        const newSandbox = new Sandbox({
            name, problemStatement, initialWallet, target, timeLimit, option1, option2, option3, option4
        })

        await newSandbox.save();
        return new Response(JSON.stringify(newSandbox), { status: 201 })
    } catch (error) {
        console.log(error);
        return new Response("Failed to create a new sandbox..", { status: 500 })
    }
}