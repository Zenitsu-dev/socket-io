// pages/api/users/route.js
import User from "@/models/users";
import { connectToDB } from "@/utils/database";

export const GET = async (request) => {
  const url = new URL(request.url);
  const id = url.searchParams.get('id');  // Correctly extract the `id` from the query parameters

  try {
    await connectToDB();

    if (!id) {
      return new Response("Missing `id` query parameter", { status: 400 });
    }

    const user = await User.findOne({ clerkId: id });

    if (!user) {
      return new Response("User Not Found", { status: 404 });
    }

    return new Response(JSON.stringify(user), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response("Internal Server Error", { status: 500 });
  }
};

export const PATCH = async (request) => {
  const { userId, expPoints, gold } = await request.json();

  try {
    await connectToDB();

    const user = await User.findOne({ clerkId: userId });

    if (!user) {
      return new Response("User Not Found", { status: 404 });
    }

    user.expPoints += expPoints;
    user.gold += gold;

    await user.save();

    return new Response(JSON.stringify(user), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error updating user points:", error);
    return new Response("Internal Server Error", { status: 500 });
  }
};