import { connectToDB } from "@/utils/database";
import Issue from "@/models/issues";

export async function GET(req) {
  try {
    await connectToDB();
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get("userId");

    let issues;

    if (userId === "null" || !userId) {
      // Fetch all issues with comments
      issues = await Issue.find().populate('comments.userId', 'username'); // Populating comments with userId's username
    } else {
      // Fetch community issues where userId is not equal to the provided userId
      issues = await Issue.find({ userId })
                          .populate('comments.userId', 'username'); 
    }

    return new Response(JSON.stringify(issues), { status: 200 });
  } catch (error) {
    return new Response(JSON.stringify({ message: error.message }), { status: 500 });
  }
}

export async function POST(req) {
  try {
    await connectToDB();
    const { userId, description } = await req.json();
    const newIssue = new Issue({
      userId,
      description,
      comments: [],
    });
    await newIssue.save();
    return new Response(JSON.stringify(newIssue), { status: 201 });
  } catch (error) {
    return new Response(JSON.stringify({ message: error.message }), { status: 409 });
  }
}

// export async function PATCH(req) {
//   try {
//     await connectToDB();
//     const { issueId, comment, userId } = await req.json();
//     const issue = await Issue.findById(issueId);

//     if (issue) {
//       issue.comments.push({ comment, userId });
//       await issue.save();
//       return new Response(JSON.stringify(issue), { status: 200 });
//     } else {
//       return new Response(JSON.stringify({ message: "Issue not found" }), { status: 404 });
//     }
//   } catch (error) {
//     return new Response(JSON.stringify({ message: error.message }), { status: 500 });
//   }
// }
