import { connectToDB } from "@/utils/database";
import Issue from "@/models/issues";

export async function GET(req) {
  try {
    await connectToDB();
    const { searchParams } = new URL(req.url);

    const issueId = searchParams.get("issueId");
    const userId = searchParams.get("userId");

    // Debugging logs
    console.log("issueId:", issueId);
    console.log("userId:", userId);

    if (issueId) {
      // Fetch a specific issue by `issueId`
      const issue = await Issue.findById(issueId).lean().exec(); // Use `lean()` to get plain JavaScript objects

      if (issue) {
        return new Response(JSON.stringify(issue), { status: 200 });
      } else {
        return new Response(JSON.stringify({ message: "Issue not found" }), { status: 404 });
      }
    } else if (userId) {
      // Fetch issues for a specific user by `userId`
      const issues = await Issue.find({ userId: userId }) // Ensure `userId` is used correctly

      console.log("Fetched issues:", issues); // Debugging log for issues

      if (issues.length > 0) {
        return new Response(JSON.stringify(issues), { status: 200 });
      } else {
        return new Response(JSON.stringify({ message: "No issues found for the user" }), { status: 404 });
      }
    } else {
      return new Response(JSON.stringify({ message: "issueId or userId parameter is required" }), { status: 400 });
    }
  } catch (error) {
    return new Response(JSON.stringify({ message: error.message }), { status: 500 });
  }
}



// PATCH request to add a comment to a specific issue
export async function PATCH(req) {
  try {
    await connectToDB();
    const { issueId, comment, userId } = await req.json();

    if (typeof comment !== 'string') {
      throw new Error('Comment must be a string');
    }

    const issue = await Issue.findById(issueId);

    if (issue) {
      issue.comments.push({ userId, comment });
      await issue.save();
      return new Response(JSON.stringify(issue), { status: 200 });
    } else {
      return new Response(JSON.stringify({ message: "Issue not found" }), { status: 404 });
    }
  } catch (error) {
    return new Response(JSON.stringify({ message: error.message }), { status: 500 });
  }
}

// DELETE request to delete a specific issue
export async function DELETE(req) {
  try {
    await connectToDB();
    const { searchParams } = new URL(req.url);
    const issueId = searchParams.get("issueId");

    if (issueId) {
      // Delete the specific issue by `issueId`
      const result = await Issue.findByIdAndDelete(issueId);

      if (result) {
        return new Response(JSON.stringify({ message: "Issue deleted successfully" }), { status: 200 });
      } else {
        return new Response(JSON.stringify({ message: "Issue not found" }), { status: 404 });
      }
    } else {
      return new Response(JSON.stringify({ message: "issueId parameter is required" }), { status: 400 });
    }
  } catch (error) {
    return new Response(JSON.stringify({ message: error.message }), { status: 500 });
  }
}
