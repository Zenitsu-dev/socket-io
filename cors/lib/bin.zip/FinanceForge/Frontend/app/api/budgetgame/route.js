import { connectToDB } from "@/utils/database";
import Budgetgame from "@/models/budgetgames";

export const POST = async (req) => {
    const { name, budget, time } = await req.json();


    try {
        await connectToDB();
        const newgame = new Budgetgame({
            name, budget, time
        })

        await newgame.save();
        return new Response(newgame, { status: 201 })
    } catch (error) {
        console.log(error);
        return new Response("Failed to create a new budgetgame..", { status: 500 })
    }
}