import Image from "next/image";

export default function RootLayout({ children }) {
  return (
    <main className="relative h-screen w-full">
      <div className="absolute inset-0" style={{ backdropFilter: "blur(8px)" }}>
        <Image src="https://images.freeimages.com/images/large-previews/e87/finance-related-1636006.jpg" alt="background" layout="fill" unoptimized />
      </div>

      {children}
    </main>
  );
}
