"use client";
import Image from "next/image";
import React, { useEffect, useState } from "react";

const Simulation = () => {
  const initialWallet = 10000;
  const target = 100000;
  const time = 20;
  const goldPrice = [
    70000, 72500, 75000, 73000, 78000, 85000, 82000, 88000, 95000, 90000, 98000,
    106000, 102000, 112000, 123000, 118000, 130000, 142000, 137000, 150000,
  ];
  const [goldInvestment, setGoldInvestment] = useState(0);

  const stockPrice = [
    100, 115, 130, 120, 145, 170, 160, 190, 220, 205, 240, 275, 260, 300, 340,
    320, 365, 410, 390, 440,
  ];
  const [stockInvested, setStockInvested] = useState(0);

  const bitcoinPrice = [
    90000, 92000, 94000, 92000, 96000, 100000, 98000, 104000, 110000, 106000,
    115000, 124000, 120000, 130000, 140000, 135000, 150000, 165000, 160000,
    180000,
  ];
  const [bitcoinInvested, setBitcoinInvested] = useState(0);

  const [FDrate, setFDrate] = useState(15);
  const [FDinvested, setFDinvested] = useState(0);

  const [wallet, setWallet] = useState(initialWallet);
  const [amountInvested, setAmountInvested] = useState(0);
  const [timeElapsed, setTimeElapsed] = useState(0);

  useEffect(() => {
    setAmountInvested(
      parseInt(goldInvestment) +
        parseInt(stockInvested) +
        parseInt(bitcoinInvested) +
        parseInt(FDinvested)
    );
  }, [goldInvestment, stockInvested, bitcoinInvested, FDinvested]);

  const elapseTime = () => {
    debugger;
    if (amountInvested <= wallet) {
      if (timeElapsed < time) {
        setTimeElapsed(timeElapsed + 1);
        // Calculate new investments based on price changes

        var interest =
          parseInt(goldPrice[timeElapsed + 1]) -
          parseInt(goldPrice[timeElapsed]);
        var equity = goldInvestment / goldPrice[timeElapsed];
        var dividend = parseInt(interest * equity);
        var newGoldInvestment = parseInt(goldInvestment) + dividend;
        setGoldInvestment(newGoldInvestment);

        // Add similar calculations for stocks and bitcoin
        const newStockInvestment =
          stockInvested +
          (stockPrice[timeElapsed + 1] - stockPrice[timeElapsed]) *
            (stockInvested / stockPrice[timeElapsed]);
        setStockInvested(newStockInvestment);

        const newBitcoinInvestment =
          bitcoinInvested +
          (bitcoinPrice[timeElapsed + 1] - bitcoinPrice[timeElapsed]) *
            (bitcoinInvested / bitcoinPrice[timeElapsed]);
        setBitcoinInvested(newBitcoinInvestment);
      } else {
        alert("Simulation over!");
      }
    } else {
      alert("Investment exceeds wallet capacity.");
    }
  };

  return (
    <div className="flex flex-col items-start text-white-2 m-6 gap-10">
      <h1 className="text-3xl font-bold">Investment Sandbox</h1>
      <div className="description">
        <p className="text-lg">
          <b>Problem Statement</b>: Lorem ipsum dolor sit amet, consectetur
          adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
          magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation
          ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute
          irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
          fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
          sunt in culpa qui officia deserunt mollit anim id est laborum.
        </p>
      </div>
      <div className="stats flex flex-row gap-6">
        <div className="wallet flex flex-col">
          <h1 className="text-2xl font-bold">Initial saving</h1>
          <h1 className="text-xl font-medium">${initialWallet}</h1>
        </div>
        <div className="wallet flex flex-col">
          <h1 className="text-2xl font-bold">Wallet</h1>
          <h1 className="text-xl font-medium">${wallet}</h1>
        </div>
        <div className="Target flex flex-col">
          <h1 className="text-2xl font-bold">Target</h1>
          <h1 className="text-xl font-medium">${target}</h1>
        </div>
        <div className="TimeLimit flex flex-col">
          <h1 className="text-2xl font-bold">Time</h1>
          <h1 className="text-xl font-medium">{time} years</h1>
        </div>
      </div>
      {/* Options */}
      <div className="options flex flex-row gap-6 w-full justify-center">
        <div className="optionContainer p-5 flex flex-col items-center gap-3">
          <Image src={"/icons/gold.svg"} width={120} height={120} />
          <h1 className="text-lg font-bold text-white-1">Gold</h1>
          <p>Price: {goldPrice[timeElapsed]}</p>
          <div className="optionInput">
            <input
              className="p-1 rounded w-44 bg-black-2 text-center"
              onChange={(e) => setGoldInvestment(e.target.value)}
              type="number"
              name="gold"
              id="gold"
              placeholder="enter amount to invest"
              value={goldInvestment}
            />
          </div>
        </div>

        <div className="optionContainer p-5 flex flex-col items-center gap-3">
          <Image src={"/icons/FD.svg"} width={120} height={120} />
          <h1 className="text-lg font-bold text-white-1">Fixed Deposit</h1>
          <p>Rate: {FDrate}%</p>
          <div className="optionInput">
            <input
              className="p-1 rounded w-44 bg-black-2 text-center"
              onChange={(e) => setFDinvested(e.target.value)}
              type="number"
              name="FD"
              id="FD"
              placeholder="enter amount to invest"
              value={FDinvested}
            />
          </div>
        </div>

        <div className="optionContainer  p-5 flex flex-col items-center gap-3">
          <Image src={"/icons/stocks.svg"} width={120} height={120} />
          <h1 className="text-lg font-bold text-white-1">Stock</h1>
          <p>Price: {stockPrice[timeElapsed]}</p>
          <div className="optionInput">
            <input
              className="p-1 rounded w-44 bg-black-2 text-center"
              onChange={(e) => setStockInvested(e.target.value)}
              type="number"
              name="stock"
              id="stock"
              placeholder="enter amount to invest"
              value={stockInvested}
            />
          </div>
        </div>

        <div className="optionContainer  p-5 flex flex-col items-center gap-3">
          <Image src={"/icons/bitcoin.svg"} width={120} height={120} />
          <h1 className="text-lg font-bold text-white-1">Bitcoin</h1>
          <p>Price: {bitcoinPrice[timeElapsed]}</p>
          <div className="optionInput">
            <input
              className="p-1 rounded w-44 bg-black-2 text-center"
              onChange={(e) => setBitcoinInvested(e.target.value)}
              type="number"
              name="gold"
              id="gold"
              placeholder="enter amount to invest"
              value={bitcoinInvested}
            />
          </div>
        </div>
      </div>
      <div className="flex flex-row w-full justify-between">
        <div className="Totalinvested">
          <h1 className="text-2xl font-bold">
            Total Investment: {amountInvested}
          </h1>
        </div>
        <div className="clock flex flex-row items-center gap-8">
          <button
            className="bg-[#f97535] p-2 rounded-full"
            onClick={() => elapseTime()}
          >
            <Image src={"/icons/clock.svg"} width={35} height={35} />
          </button>
          <p className="text-lg font-bold text-white-1">
            Time elapsed: {timeElapsed} years
          </p>
        </div>
      </div>
    </div>
  );
};

export default Simulation;
