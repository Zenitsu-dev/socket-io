import ProductRecommendation from '@/components/ProductRecommendation';

const Recommend = () => {
  return (
    <div>
      <ProductRecommendation />
    </div>
  );
};

export default Recommend;
