"use client";
import { useState, useEffect } from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowUp } from '@fortawesome/free-solid-svg-icons';
import { useUser } from "@clerk/nextjs";

export default function IssuePage({ params }) {
  const { user } = useUser();
  const { issueId } = params;
  const [issue, setIssue] = useState(null);
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [upvotedComments, setUpvotedComments] = useState([]);

  const handleUpvotes = async (commentId, id) => {
    try {
      const response = await fetch('/api/users', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: id, expPoints: 2, gold: 5 }), // Update as needed
      });
      if (response.ok) {
        setUpvotedComments((prev) => [...prev, commentId]);
      } else {
        console.error('Failed to upvote');
      }
    } catch (error) {
      console.error("error", error);
    }
  };

  useEffect(() => {
    const fetchIssue = async () => {
      try {
        const response = await fetch(`/api/issues?issueId=${issueId}`);
        if (response.ok) {
          const data = await response.json();
          setIssue(data);
          setComments(data.comments || []);
        } else {
          console.error("Failed to fetch issue");
        }
      } catch (error) {
        console.error("Error fetching issue:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchIssue();
  }, [issueId]);

  if (loading || !user) {
    return <p>Loading...</p>;
  }

  if (!issue) {
    return <p>Issue not found</p>;
  }

  return (
    <section className="mt-16 mx-16">
      <h1 className="text-2xl font-bold text-white-1 mb-6">Issue and Comments</h1>
      <div className="mb-6 p-4 bg-gray-800 rounded-lg border border-gray-700">
        <h2 className="text-xl font-semibold text-white-1 mb-2">Issue Description</h2>
        <p className="text-white-1">{issue.description}</p>
      </div>
      <div className="mb-6">
        {comments.length > 0 ? (
          comments.map((comment) => (
            <div key={comment._id} className="mb-4 p-4 bg-gray-700 rounded-lg border border-gray-600 flex justify-between items-center w-3/4">
              <p className="text-white-1">
                <strong>{comment.userId || "Anonymous"}:</strong> {comment.comment}
              </p>
              {comment.userId !== user.id && (
                <button
                  onClick={() => handleUpvotes(comment._id, comment.userId)}
                  className={`mt-2 py-1 px-4 cl-formButtonPrimary text-white rounded-lg hover:bg-orange-400 ${upvotedComments.includes(comment._id) ? 'bg-transparent text-gray-400 cursor-not-allowed' : ''}`}
                  disabled={upvotedComments.includes(comment._id)}
                >
                  <FontAwesomeIcon icon={faArrowUp} />
                </button>
              )}
            </div>
          ))
        ) : (
          <p className="text-gray-400">No comments yet.</p>
        )}
      </div>
    </section>
  );
}
