"use client";
import { useState, useEffect } from "react";
import { useUser } from "@clerk/nextjs";

export default function CommunityIssues() {
  const { user } = useUser();
  const [issues, setIssues] = useState([]);
  const [activeCommentIssueId, setActiveCommentIssueId] = useState(null);
  const [newComment, setNewComment] = useState("");

  useEffect(() => {
    const fetchIssues = async () => {
      try {
        const response = await fetch('/api/community-chat');
        if (response.ok) {
          const data = await response.json();
          setIssues(data);
        } else {
          console.error("Failed to fetch issues");
        }
      } catch (error) {
        console.error("Error fetching issues:", error);
      }
    };

    fetchIssues();
  }, []);

  const handleAddCommentClick = (issueId) => {
    setActiveCommentIssueId(issueId);
  };

  const handleCommentChange = (e) => {
    setNewComment(e.target.value);
  };

  const handleCommentSubmit = async (issueId) => {
    if (!newComment.trim()) {
      return;
    }

    try {
      const response = await fetch(`/api/issues`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          issueId,
          comment: newComment,
          userId: user.id,
        }),
      });

      if (response.ok) {
        const updatedIssue = await response.json();
        setIssues((prevIssues) =>
          prevIssues.map((issue) =>
            issue._id === updatedIssue._id ? updatedIssue : issue
          )
        );
        setActiveCommentIssueId(null);
        setNewComment("");
      } else {
        console.error("Failed to add comment");
      }
    } catch (error) {
      console.error("Error adding comment:", error);
    }
  };

  return (
    <section className="mt-16 mx-16">
      <h1 className="text-2xl font-bold text-white-1 mb-6">Community Issues</h1>
      {issues.length > 0 ? (
        issues.map((issue) => (
          <div key={issue._id} className="mb-4 p-4 bg-gray-800 rounded-lg border border-gray-700">
            <p className="text-white-1">{issue.description}</p>
            <a
              href={`/issue/${issue._id}`}
              className="text-blue-400 hover:text-blue-300 mt-2 inline-block"
            >
              View Comments
            </a>
            {activeCommentIssueId === issue._id ? (
              <div className="mt-2">
                <textarea
                  value={newComment}
                  onChange={handleCommentChange}
                  className="w-full p-2 rounded-lg border border-gray-700 bg-gray-800 text-white-1"
                  rows="3"
                  placeholder="Write your comment here..."
                ></textarea>
                <button
                  onClick={() => handleCommentSubmit(issue._id)}
                  className="text-green-400 hover:text-green-300 mt-2 inline-block"
                >
                  Submit Comment
                </button>
              </div>
            ) : (
              <button
                onClick={() => handleAddCommentClick(issue._id)}
                className="text-green-400 hover:text-green-300 mt-2 ml-4 inline-block"
              >
                Add Comment
              </button>
            )}
          </div>
        ))
      ) : (
        <p className="text-gray-400">No issues found.</p>
      )}
    </section>
  );
}