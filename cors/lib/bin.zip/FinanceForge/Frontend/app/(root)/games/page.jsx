"use client";
import { getAllBudgetgames } from "@/utils/actions/budgetgameActions";
import { getAllSandboxes } from "@/utils/actions/sandboxActions";
import Link from "next/link";
import React, { useEffect, useState } from "react";

const games = () => {
  const [sandboxes, setSandboxes] = useState(null);
  const [budgetGames, setBudgetGames] = useState(null);

  // Fetch all sandboxes data
  useEffect(() => {
    const fetchData = async () => {
      try {
        debugger;
        const sandboxesData = await getAllSandboxes();
        const budgetGamesData = await getAllBudgetgames();
        setSandboxes(JSON.parse(sandboxesData));
        setBudgetGames(JSON.parse(budgetGamesData));
        console.log(JSON.parse(sandboxesData));
        console.log(JSON.parse(budgetGamesData));
      } catch (error) {
        console.error("Error fetching data:", error.message);
      }
    };
    fetchData();
  }, []);

  return (
    <div className="container flex flex-col text-white-2 mt-7 ml-2">
      <div className="font-bold text-4xl">Games</div>
      <div className="flex flex-row w-full mt-5">
        <div className="investment w-1/2">
          <p className="text-2xl">Investment Sandbox</p>
          {sandboxes?.map((sandbox) => {
            return (
              <Link href={`/games/investment-sandbox/${sandbox._id}`}>
                <div
                  key={sandbox.id}
                  className="flex flex-col gap-2 bg-black-1 p-4 m-3 rounded-md"
                >
                  <p className="text-xl">{sandbox.name}</p>
                  <p>
                    Problem statement:{" "}
                    {sandbox.problemStatement.substring(0, 115)}..
                    <br />
                    Time: {sandbox.timeLimit} weeks, <br /> initial investment:{" "}
                    {sandbox.initialWallet}, Target: {sandbox.target}
                  </p>
                </div>
              </Link>
            );
          })}
        </div>
        <div className="budgetGame w-1/2 border-l-[1px] border-gray-400 pl-6">
          <p className="text-2xl">Budget Game</p>
          {budgetGames?.map((budgetGame) => {
            return (
              <Link href={`/games/budget-game/${budgetGame._id}`}>
                <div
                  key={budgetGame.id}
                  className="flex flex-col gap-2 bg-black-1 p-4 m-3 rounded-md"
                >
                  <p className="text-xl">{budgetGame.name}</p>
                  <p>
                    Time: {budgetGame.time} weeks, <br />
                    Budget: {budgetGame.budget}
                  </p>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default games;
