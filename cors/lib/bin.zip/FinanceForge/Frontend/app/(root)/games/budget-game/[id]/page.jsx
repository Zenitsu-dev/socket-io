"use client";
import Image from "next/image";
import React, { useEffect, useState } from "react";
import { items } from "@/consts/items";
import { fetchBudgetGame } from "@/utils/actions/budgetgameActions";
import {
  Dialog,
  DialogBackdrop,
  DialogPanel,
  DialogTitle,
} from "@headlessui/react";

import { ExclamationTriangleIcon } from "@heroicons/react/24/outline";
import { updateReward } from "@/utils/actions/action";
import Link from "next/link";
import { useUser } from "@clerk/nextjs";

const budgetGame = ({ params }) => {
  const { isSignedIn, user } = useUser();
  const [budgetGame, setBudgetGame] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      if (budgetGame === null) {
        try {
          const data = await fetchBudgetGame(params.id);
          const gameData = JSON.parse(data);
          setBudgetGame(gameData);
          setBalance(gameData.budget);
        } catch (error) {
          console.error("Error fetching sandbox:", error.message);
        }
      }
    };
    fetchData();
  }, [params.id, budgetGame]);

  const [fun, setFun] = useState(0);
  const [comfort, setComfort] = useState(0);
  const [health, setHealth] = useState(0);
  const [wellbeing, setWellbeing] = useState(0);
  const [balance, setBalance] = useState(0);
  const [currentWeek, setCurrentWeek] = useState(0);

  const [weekCost, setWeekCost] = useState(0);

  const [item, setItem] = useState({
    type: "",
    name: "",
    description: "",
    cost: 0,
    fun: 0,
    comfort: 0,
    health: 0,
  });

  const sections = ["Messages", "Finances", "Activities", "Food", "Travel"];

  const [selectedSection, setSelectedSection] = useState("Activities");

  const activities = [
    "Gym",
    "Running",
    "Swimming",
    "Football",
    "Golf",
    "Cinema",
    "Meet friends",
    "Walking",
    "Day Out",
    "Live show",
  ];
  const foodItems = [
    "Fine dining",
    "Home cooking",
    "Takeaway",
    "Convenience food",
    "Fast food",
    "Local restaurant",
  ];
  const travelItems = ["Public Transport", "Car", "Bicycle", "Taxi"];

  const [selectedItems, setSelectedItems] = useState({
    SoW: {
      Activities: null,
      Food: null,
      Travel: null,
    },
    MoW: {
      Activities: null,
      Food: null,
      Travel: null,
    },
    EoW: {
      Activities: null,
      Food: null,
      Travel: null,
    },
  });

  const handleItemSelect = (event, weekPhase) => {
    const selectedItem = items.find((i) => i.name === event.target.value);
    setItem(selectedItem);
    setSelectedItems((prevItems) => ({
      ...prevItems,
      [weekPhase]: {
        ...prevItems[weekPhase],
        [selectedSection]: selectedItem,
      },
    }));
  };

  const [message, setMessage] = useState("");

  const calculateWeeklyChanges = () => {
    console.log("Start of week:", selectedItems.SoW);
    console.log("Mid of week:", selectedItems.MoW);
    console.log("End of week:", selectedItems.EoW);
    let totalCost = 0;
    let totalFun = 0;
    let totalComfort = 0;
    let totalHealth = 0;

    // Iterate through each week phase and each item type
    Object.keys(selectedItems).forEach((weekPhase) => {
      Object.keys(selectedItems[weekPhase]).forEach((type) => {
        const item = selectedItems[weekPhase][type];
        if (item) {
          totalCost += item.cost;
          totalFun += item.fun;
          totalComfort += item.comfort;
          totalHealth += item.health;
        }
      });
    });

    setBalance((prevBalance) => prevBalance - totalCost);
    setFun((prevFun) => prevFun + totalFun);
    setComfort((prevComfort) => prevComfort + totalComfort);
    setHealth((prevHealth) => prevHealth + totalHealth);
    setWeekCost(totalCost);
    setCurrentWeek((prevWeek) => prevWeek + 1);

    if (currentWeek == budgetGame?.time && balance > 0) {
      setMessage("Congratulations! You managed your budget successfully!");
      setOpen(true);
      const req = updateReward(100, 100, user.id);
      return;
    }

    if (balance <= 0) {
      setMessage("Oh no! You are out of your budget");
      setOpen(true);
      const req = updateReward(20, 20, user.id);
      return;
    }

    // Reset selected items after calculation
    setSelectedItems({
      SoW: { Activities: null, Food: null, Travel: null },
      MoW: { Activities: null, Food: null, Travel: null },
      EoW: { Activities: null, Food: null, Travel: null },
    });
  };

  const [open, setOpen] = useState(false);

  return (
    <div className="gameContainer text-white-2 m-2">
      <Dialog className="relative z-10" open={open} onClose={setOpen}>
        <DialogBackdrop
          transition
          className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity data-[closed]:opacity-0 data-[enter]:duration-300 data-[leave]:duration-200 data-[enter]:ease-out data-[leave]:ease-in"
        />

        <div className="fixed inset-0 z-10 w-screen overflow-y-auto">
          <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
            <DialogPanel
              transition
              className="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all data-[closed]:translate-y-4 data-[closed]:opacity-0 data-[enter]:duration-300 data-[leave]:duration-200 data-[enter]:ease-out data-[leave]:ease-in sm:my-8 sm:w-full sm:max-w-lg data-[closed]:sm:translate-y-0 data-[closed]:sm:scale-95"
            >
              <div className="bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  <div className="mx-auto flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-full bg-red-100 sm:mx-0 sm:h-10 sm:w-10">
                    <ExclamationTriangleIcon
                      className="h-6 w-6 text-red-600"
                      aria-hidden="true"
                    />
                  </div>
                  <div className="mt-3 text-center sm:ml-4 sm:mt-0 sm:text-left">
                    <DialogTitle
                      as="h3"
                      className="text-base font-semibold leading-6 text-gray-900"
                    >
                      Game Over
                    </DialogTitle>
                    <div className="mt-2">
                      <p className="text-sm text-gray-500">{message}</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 px-4 py-3 sm:flex sm:flex-row-reverse sm:px-6">
                <Link
                  type="button"
                  className="inline-flex w-full justify-center rounded-md bg-red-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-red-500 sm:ml-3 sm:w-auto"
                  href={`/games`}
                >
                  Go Back
                </Link>
                <Link
                  type="button"
                  className="mt-3 inline-flex w-full justify-center rounded-md bg-white px-3 py-2 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50 sm:mt-0 sm:w-auto"
                  href={`/games/budget-game/${params.id}`}
                  data-autofocus
                >
                  Retry
                </Link>
              </div>
            </DialogPanel>
          </div>
        </div>
      </Dialog>
      <h1 className="text-3xl font-bold mt-6 ml-8">Budget Game</h1>
      <div className="statusBar flex flex-row gap-10 items-center justify-center mx-3">
        <div className="menu">
          <Image src={"/icons/3.svg"} width={50} height={50} />
        </div>

        <div className="funHealth flex flex-col gap-2">
          <div className="flex flex-row gap-2 items-center">
            <p>Fun:</p>
            <div className="progressbox bg-white-5 rounded-lg w-20 h-5">
              <div
                className={`progress rounded-lg bg-[#f97535] h-full`}
                style={{ width: `${fun}%` }}
              ></div>
            </div>
            <p>{fun}</p>
          </div>
          <div className="flex flex-row gap-2 items-center">
            <p>Health:</p>
            <div className="progressbox bg-white-5 rounded-lg w-20 h-5">
              <div
                className={`progress rounded-lg bg-[#f97535] h-full`}
                style={{ width: `${health}%` }}
              ></div>
            </div>
            <p>{health}</p>
          </div>
        </div>

        <div className="Comfort flex flex-row gap-2 items-center">
          <p>Comfort:</p>
          <div className="progressbox bg-white-5 rounded-lg w-20 h-5">
            <div
              className={`progress rounded-lg bg-[#f97535] h-full`}
              style={{ width: `${comfort}%` }}
            ></div>
          </div>
          <p>{comfort}</p>
        </div>

        <div className="wellbeingBalance p-1 flex flex-row">
          <div className="wellbeing rounded bg-white flex flex-col items-center px-3 py-2">
            <p>Wellbeing</p>
            <p>{wellbeing}</p>
          </div>
          <div className="balance rounded bg-black-4 flex flex-col items-center px-3 py-2">
            <p>Balance</p>
            <p>${balance}</p>
          </div>
        </div>

        <div className="week border-b-4 border-purple-700">
          <p>Week: {currentWeek}</p>
        </div>

        <button
          className="bg-[#f97535] px-3 py-2 rounded"
          onClick={calculateWeeklyChanges}
        >
          {" "}
          Go to <br /> next week
        </button>
      </div>
      {/* Statusbar done */}

      <div className="main  h-[450px] flex flex-row justify-between mt-4">
        <div
          className="sideBar rounded border-[#f97535] border-[3px] flex flex-col px-3 py-5 justify-between h-full"
          style={{ width: "10%" }}
        >
          <div className="navItem">
            <Image
              src={"/icons/7.svg"}
              width={70}
              height={70}
              onClick={() => {
                setSelectedSection("Messages");
              }}
            />
          </div>

          <div className="navItem">
            <Image
              src={"/icons/6.svg"}
              width={67}
              height={67}
              onClick={() => {
                setSelectedSection("Finances");
              }}
            />
          </div>

          <div className="navItem">
            <Image
              src={"/icons/1.svg"}
              width={68}
              height={68}
              onClick={() => {
                setSelectedSection("Activities");
              }}
            />
          </div>

          <div className="navItem">
            <Image
              src={"/icons/5.svg"}
              width={70}
              height={70}
              onClick={() => {
                setSelectedSection("Food");
              }}
            />
          </div>

          <div className="navItem">
            <Image
              src={"/icons/4.svg"}
              width={70}
              height={70}
              onClick={() => {
                setSelectedSection("Travel");
              }}
            />
          </div>
        </div>
        {/* SideBar done */}

        <div className="playZone" style={{ width: "60%" }}>
          <p className="text-2xl font-bold ml-5 mt-3">{selectedSection}</p>
          {(selectedSection === "Food" ||
            selectedSection === "Travel" ||
            selectedSection === "Activities") && (
            <div className="row flex flex-row justify-between">
              <div className="startOfWeek flex flex-col items-center gap-8 w-1/3">
                <p>Start of week</p>
                <select
                  name="Sow"
                  id="Sow"
                  className="bg-black-1 px-3 py-2 rounded-md"
                  onChange={(e) => handleItemSelect(e, "SoW")}
                >
                  <option key={null} value={null}>
                    {"Select an option"}
                  </option>
                  {selectedSection === "Food" &&
                    foodItems.map((item) => (
                      <option key={item} value={item}>
                        {item}
                      </option>
                    ))}
                  {selectedSection === "Travel" &&
                    travelItems.map((item) => (
                      <option key={item} value={item}>
                        {item}
                      </option>
                    ))}
                  {selectedSection === "Activities" &&
                    activities.map((item) => (
                      <option key={item} value={item}>
                        {item}
                      </option>
                    ))}
                </select>
                {/* <button className="bg-orange-400 px-3 py-2 rounded">
                  Select
                </button> */}
              </div>

              <div className="midOfWeek flex flex-col items-center gap-8 w-1/3">
                <p>Mid of week</p>
                <select
                  name="Mow"
                  id="Mow"
                  className="bg-black-1 px-3 py-2 rounded-md"
                  onChange={(e) => handleItemSelect(e, "MoW")}
                >
                  <option key={null} value={null}>
                    {"Select an option"}
                  </option>
                  {selectedSection === "Food" &&
                    foodItems.map((item) => (
                      <option key={item} value={item}>
                        {item}
                      </option>
                    ))}
                  {selectedSection === "Travel" &&
                    travelItems.map((item) => (
                      <option key={item} value={item}>
                        {item}
                      </option>
                    ))}
                  {selectedSection === "Activities" &&
                    activities.map((item) => (
                      <option key={item} value={item}>
                        {item}
                      </option>
                    ))}
                </select>
                {/* <button className="bg-orange-400 px-3 py-2 rounded">
                  Select
                </button> */}
              </div>

              <div className="endOfWeek flex flex-col items-center gap-8 w-1/3">
                <p>End of week</p>
                <select
                  name="Eow"
                  id="Eow"
                  className="bg-black-1 px-3 py-2 rounded-md"
                  onChange={(e) => handleItemSelect(e, "EoW")}
                >
                  <option key={null} value={null}>
                    {"Select an option"}
                  </option>
                  {selectedSection === "Food" &&
                    foodItems.map((item) => (
                      <option key={item} value={item}>
                        {item}
                      </option>
                    ))}
                  {selectedSection === "Travel" &&
                    travelItems.map((item) => (
                      <option key={item} value={item}>
                        {item}
                      </option>
                    ))}
                  {selectedSection === "Activities" &&
                    activities.map((item) => (
                      <option key={item} value={item}>
                        {item}
                      </option>
                    ))}
                </select>
                {/* <button className="bg-orange-400 px-3 py-2 rounded">
                  Select
                </button> */}
              </div>
            </div>
          )}
          {selectedSection == "Finances" && <>Finances</>}
          {selectedSection == "Messages" && <>Messages</>}
          <div className="transactions">
            <p>SoW</p>
            <p>{selectedItems?.SoW?.Activities?.name.toString()}</p>
            <p>{selectedItems?.SoW?.Food?.name.toString()}</p>
            <p>{selectedItems?.SoW?.Travel?.name.toString()}</p>
            <p>MoW</p>
            <p>{selectedItems?.MoW?.Activities?.name.toString()}</p>
            <p>{selectedItems?.MoW?.Food?.name.toString()}</p>
            <p>{selectedItems?.MoW?.Travel?.name.toString()}</p>
            <p>EoW</p>
            <p>{selectedItems?.EoW?.Activities?.name.toString()}</p>
            <p>{selectedItems?.EoW?.Food?.name.toString()}</p>
            <p>{selectedItems?.EoW?.Travel?.name.toString()}</p>
          </div>
        </div>

        {/* PlayZone done */}

        <div
          className="informationBar w-48 m-2 flex flex-col gap-1 "
          style={{ width: "30%" }}
        >
          <div className="itemInformation flex flex-col border-[3px] rounded border-orange-500 bg-white px-3 py-4">
            <p className="font-bold">{item.name}</p>
            <p>{item.description}</p>
            <br />
            <p>Fun: {item.fun}</p>
            <p>Comfort: {item.comfort}</p>
            <p>Health: {item.health}</p>
            <br />
            <p>Cost: ${item.cost}</p>
          </div>
          <div className="weeklyCost border-[3px] rounded border-orange-500 bg-white px-3 py-4">
            <div className="weeklyCost flex flex-col">
              <p className="font-bold">This weeks cost: ${weekCost}</p>
            </div>
          </div>
        </div>
        {/* InformationBar done */}
      </div>
    </div>
  );
};

export default budgetGame;
