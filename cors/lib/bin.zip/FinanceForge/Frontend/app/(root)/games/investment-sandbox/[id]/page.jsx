"use client";
import { fetchSandbox } from "@/utils/actions/sandboxActions";
import Image from "next/image";
import React, { useEffect, useState } from "react";

import {
  Dialog,
  DialogBackdrop,
  DialogPanel,
  DialogTitle,
} from "@headlessui/react";

import { ExclamationTriangleIcon } from "@heroicons/react/24/outline";
import Link from "next/link";
import { useUser } from "@clerk/nextjs";
import { updateReward } from "@/utils/actions/action";

const Simulation = ({ params }) => {
  const { isSignedIn, user } = useUser();
  const [sandbox, setSandbox] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      if (sandbox === null) {
        try {
          const data = await fetchSandbox(params.id);
          const sandboxData = JSON.parse(data);
          setSandbox(sandboxData);
          setWallet(sandboxData.initialWallet);
          console.log(sandboxData);
        } catch (error) {
          console.error("Error fetching sandbox:", error.message);
        }
      }
    };
    fetchData();
  }, [params.id, sandbox]);

  const [option1Investment, setOption1Investment] = useState(0);
  const [option2Investment, setOption2Investment] = useState(0);
  const [option3Investment, setOption3Investment] = useState(0);

  const time = 20;

  const [FDrate, setFDrate] = useState(15);
  const [FDinvested, setFDinvested] = useState(0);

  const [wallet, setWallet] = useState(0);
  const [amountInvested, setAmountInvested] = useState(0);
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [message, setMessage] = useState("Message");

  useEffect(() => {
    setAmountInvested(
      parseInt(option1Investment) +
        parseInt(option2Investment) +
        parseInt(option3Investment) +
        parseInt(FDinvested)
    );
  }, [option1Investment, option2Investment, option3Investment, FDinvested]);

  const elapseTime = () => {
    debugger;
    if (amountInvested <= wallet) {
      if (timeElapsed + 1 < time) {
        setTimeElapsed(timeElapsed + 1);
        // Calculate new investments based on price changes

        //calcluate and deduct money from wallet, before calculating interests
        var walletBalance = wallet - amountInvested;
        setWallet(walletBalance);

        var interest =
          parseInt(sandbox?.option1?.prices[timeElapsed + 1]) -
          parseInt(sandbox?.option1?.prices[timeElapsed]);
        var equity = option1Investment / sandbox?.option1?.prices[timeElapsed];
        var dividend = parseInt(interest * equity);
        var new1Investment = parseInt(option1Investment) + dividend;
        setOption1Investment(new1Investment);

        // Add similar calculations for stocks and bitcoin
        interest =
          parseInt(sandbox?.option2?.prices[timeElapsed + 1]) -
          parseInt(sandbox?.option2?.prices[timeElapsed]);
        equity = option2Investment / sandbox?.option2?.prices[timeElapsed];
        dividend = parseInt(interest * equity);
        const new2Investment = parseInt(option2Investment) + dividend;
        setOption2Investment(new2Investment);

        interest =
          parseInt(sandbox?.option3?.prices[timeElapsed + 1]) -
          parseInt(sandbox?.option3?.prices[timeElapsed]);
        equity = option3Investment / sandbox?.option3?.prices[timeElapsed];
        dividend = parseInt(interest * equity);
        const new3Investment = parseInt(option3Investment) + dividend;
        setOption3Investment(new3Investment);

        interest = parseInt(FDinvested) * parseFloat(FDrate / 100);
        const newFDInvestment = parseInt(FDinvested) + interest;
        setFDinvested(newFDInvestment);

        walletBalance =
          new1Investment + new2Investment + new3Investment + newFDInvestment;
        setWallet(walletBalance);

        if (walletBalance >= sandbox.target) {
          setMessage(
            "Congratulations! You won! <br/> Experience points and gold will be added to your profile."
          );
          addReward("win");
          setOpen(true);
        }
      } else {
        setTimeElapsed(timeElapsed + 1);
        setMessage("Aww snap! you ran out of time");
        addReward("lose");
        setOpen(true);
      }
    } else {
      alert("Investment exceeds wallet capacity.");
    }
  };

  const addReward = async (result) => {
    var gold = 0;
    var exp = 0;
    if (result === "win") {
      gold = 100;
      exp = 100;
    } else {
      gold = 20;
      exp = 20;
    }
    // add rewards to the user's profile
    const req = await updateReward(gold, exp, user.id);
    console.log(req);
  };

  const [open, setOpen] = useState(false);

  return (
    <div className="flex flex-col items-start text-white-2 m-6 gap-10">
      <Dialog className="relative z-10" open={open} onClose={setOpen}>
        <DialogBackdrop
          transition
          className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity data-[closed]:opacity-0 data-[enter]:duration-300 data-[leave]:duration-200 data-[enter]:ease-out data-[leave]:ease-in"
        />

        <div className="fixed inset-0 z-10 w-screen overflow-y-auto">
          <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
            <DialogPanel
              transition
              className="relative transform overflow-hidden rounded-lg bg-black-1 text-left shadow-xl transition-all data-[closed]:translate-y-4 data-[closed]:opacity-0 data-[enter]:duration-300 data-[leave]:duration-200 data-[enter]:ease-out data-[leave]:ease-in sm:my-8 sm:w-full sm:max-w-lg data-[closed]:sm:translate-y-0 data-[closed]:sm:scale-95"
            >
              <div className="bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  <div className="mx-auto flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-full bg-red-100 sm:mx-0 sm:h-10 sm:w-10">
                    <ExclamationTriangleIcon
                      className="h-6 w-6 text-red-600"
                      aria-hidden="true"
                    />
                  </div>
                  <div className="mt-3 text-center sm:ml-4 sm:mt-0 sm:text-left">
                    <DialogTitle
                      as="h3"
                      className="text-base font-semibold leading-6 text-white-2"
                    >
                      Game complete
                    </DialogTitle>
                    <div className="mt-2">
                      <p className="text-sm text-gray-500">{message}</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-black-5 px-4 py-3 sm:flex sm:flex-row-reverse sm:px-6">
                <Link
                  type="button"
                  className="inline-flex w-full justify-center rounded-md bg-[#f97535] px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-red-500 sm:ml-3 sm:w-auto"
                  href={`/games`}
                >
                  Go Back
                </Link>
                <Link
                  type="button"
                  className="mt-3 inline-flex w-full justify-center rounded-md bg-white-1 px-3 py-2 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50 sm:mt-0 sm:w-auto"
                  href={`/games/investment-sandbox/${params.id}`}
                  data-autofocus
                >
                  Retry
                </Link>
              </div>
            </DialogPanel>
          </div>
        </div>
      </Dialog>
      <h1 className="text-3xl font-bold">Investment Sandbox</h1>
      <div className="description">
        <p className="text-lg">
          <b>Problem Statement</b>: {sandbox?.problemStatement}
        </p>
      </div>
      <div className="stats flex flex-row gap-6">
        <div className="wallet flex flex-col">
          <h1 className="text-2xl font-bold">Initial saving</h1>
          <h1 className="text-xl font-medium">${sandbox?.initialWallet}</h1>
        </div>
        <div className="wallet flex flex-col">
          <h1 className="text-2xl font-bold">Wallet</h1>
          <h1 className="text-xl font-medium">${wallet}</h1>
        </div>
        <div className="Target flex flex-col">
          <h1 className="text-2xl font-bold">Target</h1>
          <h1 className="text-xl font-medium">${sandbox?.target}</h1>
        </div>
        <div className="TimeLimit flex flex-col">
          <h1 className="text-2xl font-bold">Time</h1>
          <h1 className="text-xl font-medium">{sandbox?.timeLimit} years</h1>
        </div>
      </div>
      {/* Options */}
      <div className="options flex flex-row gap-6 w-full justify-center">
        <div className="optionContainer p-5 flex flex-col items-center gap-3">
          <Image src={"/icons/gold.svg"} width={120} height={120} />
          <h1 className="text-lg font-bold text-white-1">
            {sandbox?.option1?.name}
          </h1>
          <p>value: {sandbox?.option1?.prices[timeElapsed]}</p>
          <div className="optionInput">
            <input
              className="p-1 rounded w-44 bg-black-2 text-center"
              onChange={(e) => setOption1Investment(e.target.value)}
              type="number"
              name="gold"
              id="gold"
              placeholder="enter amount to invest"
              value={option1Investment}
            />
          </div>
        </div>

        <div className="optionContainer p-5 flex flex-col items-center gap-3">
          <Image src={"/icons/FD.svg"} width={120} height={120} />
          <h1 className="text-lg font-bold text-white-1">
            {sandbox?.option2?.name}
          </h1>
          <p>value: {sandbox?.option2?.prices[timeElapsed]}</p>
          <div className="optionInput">
            <input
              className="p-1 rounded w-44 bg-black-2 text-center"
              onChange={(e) => setOption2Investment(e.target.value)}
              type="number"
              name={sandbox?.option2?.name}
              id={sandbox?.option2?.name}
              placeholder="enter amount to invest"
              value={option2Investment}
            />
          </div>
        </div>

        <div className="optionContainer  p-5 flex flex-col items-center gap-3">
          <Image src={"/icons/stocks.svg"} width={120} height={120} />
          <h1 className="text-lg font-bold text-white-1">
            {sandbox?.option3?.name}
          </h1>
          <p>value: {sandbox?.option3?.prices[timeElapsed]}</p>
          <div className="optionInput">
            <input
              className="p-1 rounded w-44 bg-black-2 text-center"
              onChange={(e) => setOption3Investment(e.target.value)}
              type="number"
              name={sandbox?.option3?.name}
              id={sandbox?.option3?.name}
              placeholder="enter amount to invest"
              value={option3Investment}
            />
          </div>
        </div>

        <div className="optionContainer  p-5 flex flex-col items-center gap-3">
          <Image src={"/icons/bitcoin.svg"} width={120} height={120} />
          <h1 className="text-lg font-bold text-white-1">Fixed Deposit</h1>
          <p>value: {FDrate}%</p>
          <div className="optionInput">
            <input
              className="p-1 rounded w-44 bg-black-2 text-center"
              onChange={(e) => setFDinvested(e.target.value)}
              type="number"
              name="FD"
              id="FD"
              placeholder="enter amount to invest"
              value={FDinvested}
            />
          </div>
        </div>
      </div>
      <div className="flex flex-row w-full justify-between">
        <div className="Totalinvested">
          <h1 className="text-2xl font-bold">
            Total Investment: {amountInvested}
          </h1>
        </div>
        <div className="clock flex flex-row items-center gap-8">
          <button
            className="bg-[#f97535] p-2 rounded-full"
            onClick={() => elapseTime()}
          >
            <Image src={"/icons/clock.svg"} width={35} height={35} />
          </button>
          <p className="text-lg font-bold text-white-1">
            Time elapsed: {timeElapsed} years
          </p>
        </div>
      </div>
    </div>
  );
};

export default Simulation;
