"use client";
import { useState, useEffect } from "react";
import { useUser } from "@clerk/nextjs";

export default function MyIssues() {
  const { user } = useUser();
  const [issues, setIssues] = useState([]);

  useEffect(() => {
    const fetchIssues = async () => {
      if (user) {
        try {
          // Fetch user from the API to get the userId
          console.log(user.id);
          const userResponse = await fetch(`/api/users?id=${user.id}`);
          if (userResponse.ok) {
            const userData = await userResponse.json();
            const userId = userData._id;  // Assume `_id` is the field you need for userId

            // Fetch issues based on the userId
            const issuesResponse = await fetch(`/api/issues?userId=${userId}`);
            if (issuesResponse.ok) {
              const data = await issuesResponse.json();
              console.log(data);  // Check fetched issues
              setIssues(data);
            } else {
              console.error("Failed to fetch issues");
            }
          } else {
            console.error("Failed to fetch user");
          }
        } catch (error) {
          console.error("Error fetching issues:", error);
        }
      }
    };

    fetchIssues();
  }, [user]);

  const handleDelete = async (issueId) => {
    try {
      const response = await fetch(`/api/issues?issueId=${issueId}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        // Remove the deleted issue from the state
        setIssues(issues.filter(issue => issue._id !== issueId));
      } else {
        console.error("Failed to delete issue");
      }
    } catch (error) {
      console.error("Error deleting issue:", error);
    }
  };

  return (
    <section className="mt-16 mx-16">
      <h1 className="text-2xl font-bold text-white-1 mb-6">My Issues</h1>
      {issues.length > 0 ? (
        issues.map((issue) => (
          <div key={issue._id} className="mb-4 p-4 bg-gray-800 rounded-lg border border-gray-700">
            <p className="text-white-1">{issue.description}</p>
            <a
              href={`/issue/${issue._id}`}
              className="text-blue-400 hover:text-blue-300 mt-2 inline-block"
            >
              View Comments
            </a>
            <button
              onClick={() => handleDelete(issue._id)}
              className="text-red-400 hover:text-red-300 mt-2 ml-4 inline-block"
            >
              Delete
            </button>
          </div>
        ))
      ) : (
        <p className="text-gray-400">You have no issues.</p>
      )}
    </section>
  );
}