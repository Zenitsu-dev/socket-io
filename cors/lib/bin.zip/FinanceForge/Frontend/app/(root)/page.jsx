"use client";
import LeftSidebar from "@/components/LeftSidebar";
import React, { useEffect } from "react";
import { useUser } from "@clerk/clerk-react";
import { createUser } from "@/utils/actions/action.js"; // Ensure this path is correct

const Home = () => {
  const { isSignedIn, user, isLoaded } = useUser();

  useEffect(() => {
    const handleUserCreation = async () => {
      try {
        if (isLoaded && isSignedIn) {
          const User = {
            clerkId: user.id,
            email: user.primaryEmailAddress.emailAddress,
            name: user.firstName,
            image: user.imageUrl,
          };

          // console.log(user);
          const newUser = await createUser(User);
          //console.log(newUser);
        }
      } catch (error) {
        console.error("Error creating user:", error);
      }
    };

    handleUserCreation();
  }, [isLoaded, isSignedIn, user]);

  return (
    <>
      <div>home is here</div>
    </>
  );
};

export default Home;
