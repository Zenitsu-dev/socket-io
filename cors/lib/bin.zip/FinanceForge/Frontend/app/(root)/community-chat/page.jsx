"use client";
import { useState } from "react";
import { useUser } from "@clerk/nextjs";

export default function CommunityChat() {
  const { user } = useUser();
  const [description, setDescription] = useState("");
  const [error, setError] = useState(null); // Add an error state

  const handleSubmit = async (e) => {
    e.preventDefault();

    const issue = {
      userId: user.id,
      description,
    };

    try {
      const response = await fetch("/api/community-chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(issue),
      });

      if (response.ok) {
        const data = await response.json();
        console.log("Issue created successfully:", data);
        setDescription("");
        setError(null); // Clear any previous errors
      } else {
        const errorData = await response.json();
        console.error("Failed to create issue:", errorData.message);
        setError(errorData.message); // Set error message from the response
      }
    } catch (error) {
      console.error("Error creating issue:", error);
      setError("An unexpected error occurred."); // Generic error message
    }
  };

  return (
    <section className="mt-16 flex flex-col text-white-1 mx-16">
      {/* Introduction Section */}
      <div className="mb-12 p-6 bg-black-2 rounded-lg border border-gray-700">
        <h1 className="text-24 font-bold text-white mb-4">
          Welcome to the Community Forum
        </h1>
        <p className="text-16 text-gray-300 mb-4">
          This is a space where you can both share your own financial issues and help others with theirs. Here’s how you can engage:
        </p>
        <div className="bg-black-1 p-4 rounded-md mb-4 border border-gray-600">
          <h2 className="text-18 font-semibold text-orange-400 mb-2">Share Your Issues</h2>
          <p className="text-gray-300">
            In the "My Issues" section, you can post your financial problems or questions. This is a great opportunity to get advice from the community and see what others think.
          </p>
        </div>
        <div className="bg-black-1 p-4 rounded-md mb-4 border border-gray-600">
          <h2 className="text-18 font-semibold text-orange-400 mb-2">Help Others Solve Their Issues</h2>
          <p className="text-gray-300">
            In the "Community Issues" section, you can browse through issues posted by other users. Offer your solutions or suggestions to earn experience points and gold coins!
          </p>
        </div>
        <div className="bg-black-1 p-4 rounded-md border border-gray-600">
          <h2 className="text-18 font-semibold text-orange-400 mb-2">Earn Rewards</h2>
          <p className="text-gray-300">
            By participating in the community and solving problems, you can earn rewards. The more you help, the more experience points and gold coins you collect!
          </p>
        </div>
      </div>

      {/* Buttons to Toggle Sections */}
      <div className="flex justify-center gap-4 mb-8">
        <a href="/my-issues" className="text-16 py-2 px-4 font-extrabold transition-all duration-500 rounded bg-orange-1 text-white hover:bg-black-1">
          My Issues
        </a>
        <a href="/community-issues" className="text-16 py-2 px-4 font-extrabold transition-all duration-500 rounded bg-gray-700 text-gray-300 hover:bg-gray-600">
          Community Issues
        </a>
      </div>

      {/* Add Issue Section */}
      <div className="mt-12 p-6 bg-black-2 rounded-lg border border-gray-700">
        <h1 className="text-20 font-bold text-white mb-4">Add a New Issue</h1>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <textarea
            placeholder="Describe your issue..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="p-2 border border-gray-300 rounded bg-black-1 text-white outline-none focus:ring-2 focus:ring-orange-500"
          />
          <button type="submit" className="text-16 bg-orange-1 py-2 px-4 font-extrabold text-white transition-all duration-500 hover:bg-black-1">
            Submit Issue
          </button>
          {error && <p className="text-red-500 mt-2">{error}</p>} {/* Display the error message */}
        </form>
      </div>
    </section>
  );
}
