"use client";
import CategoryDoughnut from "@/components/CategoryDoughnut";
import Doughnut from "@/components/Doughnut";
import LineChartMonthly from "@/components/LineChartMonthly";
import TransactionList from "@/components/TransactionList";
import { getTransactions } from "@/utils/actions/trackerActions";
import { useUser } from "@clerk/nextjs";
import Link from "next/link";
import React, { useEffect, useState } from "react";

const dashboard = () => {
  const { isLoaded, isSignedIn, user } = useUser();

  const [data, setData] = useState(null);

  useEffect(() => {
    // Fetch data here
    const fetchTransactions = async () => {
      if (isLoaded) {
        debugger;
        console.log(user.id);
        const res = await getTransactions(user?.id);
        setData(JSON.parse(res).transactions);
        console.log(JSON.parse(res).transactions);
      }
    };

    fetchTransactions(); // Call this function when component mounts or when user data changes
  }, [isLoaded, user]);

  return (
    <div className="container flex flex-col text-white-2 mt-8 w-full">
      <h1 className="text-3xl">Welcome to your personal Expense tracker!</h1>
      <div className="row flex flex-row gap-6 h-full w-full mt-5 ">
        <div className="flex flex-col gap-4 left w-3/5 h-full">
          {data && <LineChartMonthly data={data} />}{" "}
          {/*  canvas for monthly expense income line chart*/}
          <Link href={"/expense-tracker/add-transaction"} className=" w-full">
            <button className=" w-full bg-black-1 py-4 text-xl rounded-xl">
              + Add transaction
            </button>
          </Link>
          {data && <TransactionList data={data} />}
        </div>

        <div className="right w-2/5 h-full flex flex-col gap-4">
          {data && <Doughnut data={data} />}
          {data && <CategoryDoughnut data={data} />}
        </div>
      </div>
    </div>
  );
};

export default dashboard;
