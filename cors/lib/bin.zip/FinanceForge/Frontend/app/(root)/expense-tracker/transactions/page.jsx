"use client";
import { getTransactions } from "@/utils/actions/trackerActions";
import { useUser } from "@clerk/nextjs";
import React, { useEffect, useState } from "react";

const Transactions = () => {
  const { isLoaded, isSignedIn, user } = useUser();

  const [data, setData] = useState(null);

  useEffect(() => {
    // Fetch data here
    const fetchTransactions = async () => {
      if (isLoaded) {
        debugger;
        console.log(user.id);
        const res = await getTransactions(user?.id);
        setData(JSON.parse(res).transactions);
        console.log(JSON.parse(res).transactions);
      }
    };

    fetchTransactions(); // Call this function when component mounts or when user data changes
  }, [isLoaded, user]);
  return (
    <div className="container text-white-2 mt-5">
      <h1 className="text-3xl font-bold mb-4">Transactions</h1>
      <div className="list flex flex-col gap-3">
        {data &&
          data.map((transaction) => (
            <div
              key={transaction.id}
              className="bg-black-1 flex flex-col gap-1 p-3 text-lg rounded-lg"
            >
              <p
                className={`text-xl ${
                  transaction.type == "expense"
                    ? `text-[#EB5757]`
                    : `text-[#20C997]`
                }`}
              >
                {transaction.title}
              </p>
              <p>Type: {transaction.type}</p>
              <p>Amount: {transaction.amount}</p>
              <p>Category: {transaction.category}</p>
              <p>Description: {transaction.description}</p>
              <p>Date: {new Date(transaction.date).toLocaleDateString()}</p>
            </div>
          ))}
      </div>
    </div>
  );
};

export default Transactions;
