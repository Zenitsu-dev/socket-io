"use client";
import { addTransaction } from "@/utils/actions/trackerActions";
import { useUser } from "@clerk/nextjs";
import React, { useState } from "react";

const Form = () => {
  const { isSignedIn, user } = useUser();
  const categories = [
    "Food & Drinks",
    "Groceries",
    "Bills",
    "Entertainment",
    "Transportation",
    "Utilities",
    "Health & Fitness",
    "Home & Personal Care",
    "Miscellaneous",
    "Salary",
    "Dividends",
  ];

  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("");
  const [type, setType] = useState("");
  const [amount, setAmount] = useState(0);
  const [description, setDescription] = useState("");

  const handleCategorySelect = (e) => {
    setCategory(e.target.value);
  };

  const handleTypeSelect = (e) => {
    setType(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!isSignedIn || !user) {
      console.error("User not signed in");
      return;
    }

    const data = {
      userId: user.id,
      title,
      category,
      type,
      amount: parseFloat(amount),
      description,
    };

    try {
      const response = await addTransaction(data);
      console.log(response);
      // Reset form after submission
      setTitle("");
      setCategory("");
      setType("");
      setAmount(0);
      setDescription("");
    } catch (error) {
      console.error("Error adding transaction", error);
    }
  };

  return (
    <div className="container m-3 mt-10 text-white-1 text-xl">
      <h1 className="font-bold text-3xl mb-5">Add transaction</h1>
      <form className="flex flex-col gap-5" onSubmit={handleSubmit}>
        <p>Title:</p>
        <input
          type="text"
          className="bg-black-1 h-12 px-3 rounded-lg"
          placeholder="Add a title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
        <p>Amount</p>
        <input
          type="number"
          className="bg-black-1 h-12 px-3 rounded-lg"
          placeholder="Enter amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          required
        />
        <p>Category:</p>
        <select
          name="category"
          id="category"
          className="bg-black-1 h-12 px-3 rounded-lg"
          value={category}
          onChange={handleCategorySelect}
          required
        >
          <option value="">Select category</option>
          {categories.map((cat, index) => (
            <option key={index} value={cat}>
              {cat}
            </option>
          ))}
        </select>

        <p>Type:</p>
        <select
          name="type"
          id="type"
          className="bg-black-1 h-12 px-3 rounded-lg"
          value={type}
          onChange={handleTypeSelect}
          required
        >
          <option value="">Select type</option>
          <option value="income">Income</option>
          <option value="expense">Expense</option>
        </select>

        <p>Description:</p>
        <textarea
          className="bg-black-1 h-32 p-3 rounded-lg"
          placeholder="Add a description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        ></textarea>

        <button
          type="submit"
          className="bg-[#f97535] px-12 py-3 rounded-lg text-white-1"
        >
          Add transaction
        </button>
      </form>
    </div>
  );
};

export default Form;
