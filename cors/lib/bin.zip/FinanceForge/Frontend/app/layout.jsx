import { Inter } from "next/font/google";
import "./globals.css";
import { ClerkProvider } from "@clerk/nextjs";

const inter = Inter({ subsets: ["latin"] });

const metadata = {
  title: "DefaultApp",
  description: "A default application template",
  icons: {
    icon: '/icons/default-logo.svg'
  }
};

function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ClerkProvider>
          {children}
        </ClerkProvider>
      </body>
    </html>
  );
}

export default RootLayout;
export { metadata };
