"use server";

import Transaction from "@/models/transactions";
import { connectToDB } from "../database";
import { getUser } from "./action";

export const addTransaction = async (data) => {
    await connectToDB();
    const { userId, title, category, type, amount, description } = data;

    try {
        // fetching users mongo id from clerkid
        const user = await getUser(userId);
        const id = JSON.parse(user)._id;

        // Create a new transaction object
        const newTransaction = {
            title,
            type,
            amount,
            category,
            description,
            date: Date.now() // Use provided date or default to current date
        };

        // Find the user's transactions and add the new transaction
        await Transaction.findOneAndUpdate(
            { userId: id },
            { $push: { transactions: newTransaction } },
            { new: true, upsert: true } // Create a new document if it doesn't exist
        );
        console.log("Transaction added successfully.");

        return "Transaction added successfully.";
    } catch (error) {
        return "Error adding transaction." + error;
    }
}

export const getTransactions = async (id) => {
    await connectToDB();


    try {
        // fetching users mongo id from clerkid
        const user = await getUser(id);
        const userId = JSON.parse(user)._id;


        // Find the user's transactions
        const data = await Transaction.findOne({ userId: userId });


        return JSON.stringify(data);
    } catch (error) {
        return "Error getting transaction." + error;
    }
}