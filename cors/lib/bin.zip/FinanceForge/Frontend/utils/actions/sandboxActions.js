"use server"

import Sandbox from "@/models/sandbox";
import { connectToDB } from "../database";


export const fetchSandbox = async (id) => {
    try {
        await connectToDB();

        const sandbox = await Sandbox.findById(id);

        if (!sandbox) {
            throw new Error("Sandbox Not Found");
        }

        return JSON.stringify(sandbox);

    } catch (error) {
        throw new Error("Internal Server Error");
    }
}


export const getAllSandboxes = async () => {
    try {
        await connectToDB();
        const sandboxes = await Sandbox.find({});

        return JSON.stringify(sandboxes);

    } catch (error) {
        throw new Error("Internal Server Error:" + error.message);
    }
}