"use server";

import User from "@/models/users";
import { connectToDB } from "@/utils/database";

export async function createUser(user) {
  try {
    await connectToDB();
    console.log("Connected to database");
    const existingUser = await User.findOne({ clerkId: user.clerkId });
    if (existingUser) {
      console.log("User already exists");
      return existingUser.toObject();
    }
    const newUser = new User(user);
    await newUser.save();

    return newUser;
  } catch (error) {
    console.error("Error creating user:", error);
    throw error;
  }
}


export const getUser = async (id) => {
  try {
    await connectToDB();

    const user = await User.findOne({ clerkId: id });

    if (!user) {
      throw new Error("User Not Found");
    }

    return JSON.stringify(user);

  } catch (error) {
    throw new Error("Internal Server Error");
  }
}

export const updateReward = async (gold, exp, userId) => {
  try {
    await connectToDB();
    const user = await User.findOne({ clerkId: userId });

    if (!user) {
      throw new Error('User not found');
    }

    user.gold += gold;
    user.expPoints += exp;

    await user.save();

    return { success: true, gold: user.gold, expPoints: user.expPoints };
  } catch (error) {
    console.error(error);
    throw new Error('Internal Server Error');
  }
}