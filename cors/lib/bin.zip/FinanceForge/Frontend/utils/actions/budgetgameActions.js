"use server"
import Budgetgame from "@/models/budgetgames";
import { connectToDB } from "../database";


export const getAllBudgetgames = async () => {
    try {
        await connectToDB();
        const sandboxes = await Budgetgame.find({});

        return JSON.stringify(sandboxes);

    } catch (error) {
        throw new Error("Internal Server Error:" + error.message);
    }
}

export const fetchBudgetGame = async (id) => {
    try {
        await connectToDB();

        const budgetgame = await Budgetgame.findById(id);

        if (!budgetgame) {
            throw new Error("budgetgame Not Found");
        }

        return JSON.stringify(budgetgame);

    } catch (error) {
        throw new Error("Internal Server Error");
    }
}