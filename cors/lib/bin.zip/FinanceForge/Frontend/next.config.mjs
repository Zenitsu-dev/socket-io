/** @type {import('next').NextConfig} */
const nextConfig = {};

export default {
    images: {
        domains: ['img.clerk.com'],
    },
}

//  export default nextConfig;
