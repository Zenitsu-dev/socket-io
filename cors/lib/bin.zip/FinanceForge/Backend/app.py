from flask import Flask, request, jsonify
import pandas as pd
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Load data from CSV into pandas DataFrame
df = pd.read_csv('comprehensive_mutual_funds_data.csv')

# Endpoint to handle recommendation requests
@app.route('/recommend', methods=['POST'])
def get_recommendation():
    try:
        data = request.json
        # print(data)

        # Extract user inputs from JSON data
        min_lumpsum = float(data['min_lumpsum'])
        risk_level = int(data['risk_level'])
        min_returns_1yr = float(data['min_returns_1yr'])
        min_returns_3yr = float(data['min_returns_3yr'])
        min_returns_5yr = float(data['min_returns_5yr'])

        # Filter data based on user inputs
        filtered_df = df[
            (df['min_lumpsum'] <= min_lumpsum)
            & (df['risk_level'] <= risk_level)
            & (df['returns_1yr'] >= min_returns_1yr)
            & (df['returns_3yr'] >= min_returns_3yr)
            & (df['returns_5yr'] >= min_returns_5yr)
        ]

        # Sort filtered data by returns_1yr descending and get top 10 recommendations
        if not filtered_df.empty:
            sorted_df = filtered_df.sort_values(by='returns_1yr', ascending=False).head(10)
            recommendations = []
            for index, row in sorted_df.iterrows():
                scheme_details = {
                    'scheme_name': row['scheme_name'],
                    'min_sip': row['min_sip'],
                    'min_lumpsum': row['min_lumpsum'],
                    'expense_ratio': row['expense_ratio'],
                    'fund_size_cr': row['fund_size_cr'],
                    'fund_age_yr': row['fund_age_yr'],
                    'risk_level': row['risk_level'],
                    'rating': row['rating'],
                    'category': row['category'],
                    'returns_1yr': row['returns_1yr'],
                    'returns_3yr': row['returns_3yr'],
                    'returns_5yr': row['returns_5yr']
                }
                recommendations.append(scheme_details)
            return jsonify({'recommendations': recommendations})
        else:
            return jsonify({'recommendations': []})

    except KeyError as e:
        return jsonify({'error': f'Missing or incorrect key in request data: {e}'}), 400
    except Exception as e:
        print(e)
        return jsonify({'error': f'Server error: {e}'}), 500

if __name__ == '__main__':
    app.run(debug=True)
